/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package org.apache.tomcat.jni;

/** Procattr
 *
 * @author Mladen Turk
 */
public class Procattr {

    /**
     * Create and initialize a new procattr variable
     * @param cont The pool to use
     * @return The newly created procattr.
     * @throws Error An error occurred
     */
    public static native long create(long cont)
        throws Error;

    /**
     * Determine if any of stdin, stdout, or stderr should be linked to pipes
     * when starting a child process.
     * @param attr The procattr we care about.
     * @param in Should stdin be a pipe back to the parent?
     * @param out Should stdout be a pipe back to the parent?
     * @param err Should stderr be a pipe back to the parent?
     * @return the operation status
     */
    public static native int ioSet(long attr, int in, int out, int err);

    /**
     * Set the child_in and/or parent_in values to existing apr_file_t values.
     * <br>
     * This is NOT a required initializer function. This is
     * useful if you have already opened a pipe (or multiple files)
     * that you wish to use, perhaps persistently across multiple
     * process invocations - such as a log file. You can save some
     * extra function calls by not creating your own pipe since this
     * creates one in the process space for you.
     * @param attr The procattr we care about.
     * @param in apr_file_t value to use as child_in. Must be a valid file.
     * @param parent apr_file_t value to use as parent_in. Must be a valid file.
     * @return the operation status
     */
    public static native int childInSet(long attr, long in, long parent);

    /**
     * Set the child_out and parent_out values to existing apr_file_t values.
     * <br>
     * This is NOT a required initializer function. This is
     * useful if you have already opened a pipe (or multiple files)
     * that you wish to use, perhaps persistently across multiple
     * process invocations - such as a log file.
     * @param attr The procattr we care about.
     * @param out apr_file_t value to use as child_out. Must be a valid file.
     * @param parent apr_file_t value to use as parent_out. Must be a valid file.
     * @return the operation status
     */
    public static native int childOutSet(long attr, long out, long parent);

    /**
     * Set the child_err and parent_err values to existing apr_file_t values.
     * <br>
     * This is NOT a required initializer function. This is
     * useful if you have already opened a pipe (or multiple files)
     * that you wish to use, perhaps persistently across multiple
     * process invocations - such as a log file.
     * @param attr The procattr we care about.
     * @param err apr_file_t value to use as child_err. Must be a valid file.
     * @param parent apr_file_t value to use as parent_err. Must be a valid file.
     * @return the operation status
     */
    public static native int childErrSet(long attr, long err, long parent);

    /**
     * Set which directory the child process should start executing in.
     * @param attr The procattr we care about.
     * @param dir Which dir to start in.  By default, this is the same dir as
     *            the parent currently resides in, when the createprocess call
     *            is made.
     * @return the operation status
     */
    public static native int dirSet(long attr, String dir);

    /**
     * Set what type of command the child process will call.
     * @param attr The procattr we care about.
     * @param cmd The type of command.  One of:
     * <PRE>
     * APR_SHELLCMD     --  Anything that the shell can handle
     * APR_PROGRAM      --  Executable program   (default)
     * APR_PROGRAM_ENV  --  Executable program, copy environment
     * APR_PROGRAM_PATH --  Executable program on PATH, copy env
     * </PRE>
     * @return the operation status
     */
    public static native int cmdtypeSet(long attr, int cmd);

    /**
     * Determine if the child should start in detached state.
     * @param attr The procattr we care about.
     * @param detach Should the child start in detached state?  Default is no.
     * @return the operation status
     */
    public static native int detachSet(long attr, int detach);

    /**
     * Specify that apr_proc_create() should do whatever it can to report
     * failures to the caller of apr_proc_create(), rather than find out in
     * the child.
     * @param attr The procattr describing the child process to be created.
     * @param chk Flag to indicate whether pipe (sto be Procattr describing thfd_t to determine what the apr_descriptor is
     * apr_datatypeDgs_t to  nt cm thecerr sher pipe oSet(long atOcrues..ached  the child, if a bes       the caller of apr_proc_create(), rather than find out in
     * the child.
     * @param attr The procattr describing the child process to be created.
     * @param chk Flag to indicate whether pipe (sto be Procattr describing thfd_t to determine what the aNy*/
  l to udi         sescdesM5oFa iple fTwas kiOd should Tld toMn sa/
  lrogra program, copy environment
   Proaa toif a bes       the caller of apr_proc_cpy m, erogr$O g filend then wait */
  ion stThis is
     * useful if you have already opened a pipe (or multiple files)
     * that you wish to use, perhaps persistently across multiple
     * process invocations - such as a log file.
     * @param attr The procattr we care about.
     * @param err ap_nvocarhaps persis7ipe ) should .
 o.   * tm thecerr sher pi4@pasI       2 e about.ir>
 N should .
 o.   * tm thecerr sher pi4@pasI       2 e about.ir>
 N sout_1;

    /**
  atus o  2 e about.irLrLrLrLrLrLrLout.ir>
 N sole_t value to use asethen waicleile to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required b_se as      ated.
    7 have     AR0t in c e about.ir>
 N souAR0t in ccreated.
     * @param chk      *  en a pool dies.
     * ttr The oaa toif a bet.i fi should .nctil    *     *  ettr The oaa toiiorong pronent
   PPR_PARENT_BLOStrintoMn sa/
  lrogra program, copy environment
   Proaa toif a bes       the caller of apr_prormation,
tn,
     *               er
     * @pOram how How tottr The oaa toif a bes)
     * that you wA* Last ay   * Wime,        e, pers.
     *  as thistently across s argumen    * @return the ocations - such aI      eONIZE s.
     * www.apac   /**
     * Des,
    /opro  * @retursistently across m    eNSE-2.0
 *
  *  the Licenne pool that iif a be sescdesM5oFal int APR_        enne poonow-ocat           oaa toif a bes)
                                      *f  */
    public statiLL on apr_pool_t cleanup
     * A, long ee daive is.
  from
ronent
ore dump.
     * </PRE  (the "License"); you may not u