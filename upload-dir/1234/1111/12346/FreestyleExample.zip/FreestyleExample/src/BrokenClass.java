public class BrokenClass {
	public static void main(String args[]){
		System.out.println("Stand back I'm throwing an exception:");
		int x = 1/0;
	}
}