package com.AtosSyntel.myAspect;

public @interface Loggable {

}
