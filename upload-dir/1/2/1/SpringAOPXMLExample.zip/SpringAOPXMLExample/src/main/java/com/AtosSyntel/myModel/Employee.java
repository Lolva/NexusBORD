package com.AtosSyntel.myModel;

import com.AtosSyntel.myAspect.Loggable;

public class Employee {
	private String name;	
	public String getName() {
		return name;
	}
	@Loggable
	public void setName(String nm) {
		this.name=nm;
	}	
	public void throwException(){
		throw new RuntimeException("Dummy Exception");
    }	
}
